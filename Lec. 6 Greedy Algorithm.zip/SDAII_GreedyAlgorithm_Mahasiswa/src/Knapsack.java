
import java.util.Scanner;


public class Knapsack {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Tentukan Kapasitas : ");
        int K = input.nextInt();
        System.out.print("Tentukan banyak items : ");
        int item = input.nextInt();
        System.out.print("Masukan nilai weight items : ");
        int[] w_item = new int [item];
        for (int i = 0; i < w_item.length; i++)
            w_item[i] = input.nextInt();
        System.out.print("Masukan nilai profit items : ");
        int[] p_item = new int [item];
        for (int i = 0; i < p_item.length; i++)
            p_item[i] = input.nextInt();
        
        System.out.print("Silahkan Pilih Teknik :\n1. Greedy by Weight\n2. Greedy by Profit\n3. Greedy by Density\nPilih : ");
        int pilih = input.nextInt();
        int P = 0;
        
        switch(pilih) {
            case 1 :
                // Sorting from smallest to biggest
                for (int x = 0; x < item; x++) {
                    for (int y = x+1; y < item; y++) {
                        if (w_item[x] > w_item[y]) {
                            int temp1 = w_item[x];
                            int temp2 = p_item[x];
                            w_item[x] = w_item[y];
                            p_item[x] = p_item[y];
                            w_item[y] = temp1;
                            p_item[y] = temp2;
                        }
                    }
                }
                
                // Proccess Determine Items
                for (int j = 0; j < w_item.length; j++) {
                    if (K == 0)
                        break;
                    int a = K/w_item[j];
                    System.out.println(a+" item untuk weight "+w_item[j]);
                    K -= (a*w_item[j]);
                    P += (a*p_item[j]);
                }
                System.out.println("Total Profit : "+P);
                break;
            case 2 :
                // Sorting from smallest to biggest
                for (int x = 0; x < item; x++) {
                    for (int y = x+1; y < item; y++) {
                        if (p_item[x] < p_item[y]) {
                            int temp1 = w_item[x];
                            int temp2 = p_item[x];
                            w_item[x] = w_item[y];
                            p_item[x] = p_item[y];
                            w_item[y] = temp1;
                            p_item[y] = temp2;
                        }
                    }
                }
                
                // Proccess Determine Items
                for (int j = 0; j < w_item.length; j++) {
                    if (K == 0)
                        break;
                    int a = K/w_item[j];
                    System.out.println(a+" item untuk weight "+w_item[j]);
                    K -= (a*w_item[j]);
                    P += (a*p_item[j]);
                }
                System.out.println("Total Profit : "+P);
                break;
            case 3 :
                // Sorting from smallest to biggest
                float[] d_item = new float [item];
                for (int j = 0; j < d_item.length; j++)
                    d_item[j] = p_item[j]/w_item[j];
                for (int x = 0; x < item; x++) {
                    for (int y = x+1; y < item; y++) {
                        if (d_item[x] < d_item[y]) {
                            int temp1 = w_item[x];
                            int temp2 = p_item[x];
                            float temp3 = d_item[x];
                            w_item[x] = w_item[y];
                            p_item[x] = p_item[y];
                            d_item[x] = d_item[y];
                            w_item[y] = temp1;
                            p_item[y] = temp2;
                            d_item[y] = temp3;
                        }
                    }
                }
                
                // Proccess Determine Items
                for (int j = 0; j < w_item.length; j++) {
                    if (K == 0)
                        break;
                    int a = K/w_item[j];
                    System.out.println(a+" item untuk weight "+w_item[j]);
                    K -= (a*w_item[j]);
                    P += (a*p_item[j]);
                }
                System.out.println("Total Profit : "+P);
                break;
        }
    }
}
