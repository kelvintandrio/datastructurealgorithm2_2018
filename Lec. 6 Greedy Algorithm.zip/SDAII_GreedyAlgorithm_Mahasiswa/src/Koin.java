
import java.util.Scanner;

public class Koin {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Input item koin
        System.out.print("Input Banyak Item Koin : ");
        int[] item_coin = new int[input.nextInt()];
        System.out.print("Input Nilai Item Koin : ");
        for (int x = 0; x < item_coin.length; x++) {
            item_coin[x] = input.nextInt();
        }

        // Input value koin
        System.out.print("Input Nilai Koin yang ingin tukar : ");
        int coin = input.nextInt();

        // Determine the number of coins
        System.out.println("Koin ini ditukar : ");
        int optimal = 0, i = 0;
        int cad = coin;
        while (i != item_coin.length) {
            System.out.println("\nIterasi "+(i+1));
            int z = 0;
            coin = cad;
            for (int j = i; j < item_coin.length; j++) {
                int a = coin / item_coin[j];
                z += a;
                System.out.println(a + " koin untuk koin " + item_coin[j]);
                coin -= (a * item_coin[j]);
            }
            if (i == 0)
                optimal = z;
            else {
                if (z <= optimal)
                    optimal = z;
            }
            i++;
        }
        System.out.println("Jumlah koin optimal : "+optimal+" koin");
    }
}
