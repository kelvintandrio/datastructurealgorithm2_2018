
import SP.SplayTree;
import java.util.Scanner;

public class Home {
    public static void main(String[] args) {
        
    }
}
