
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Home {
    public static void main(String[] args) {
        String[][] mahasiswa = new String [16][3];
        
        // Input data mahasiswa dari file txt
        //....( Source Code ).................
        
        // Process Priority Queue looked from date graduation
        //.....( Source Code )....................
        
        // Process Priority Queue looked from faculty
        // You can make 4 array and combine become 1 array
        //........( Source Code ).....................
    }
}
