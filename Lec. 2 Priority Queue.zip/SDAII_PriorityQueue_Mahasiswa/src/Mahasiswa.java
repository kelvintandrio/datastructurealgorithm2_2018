
public class Mahasiswa {
    private String name, tgl_lulus, fakultas;
    
    public Mahasiswa(String name, String tgl_lulus, String fakultas) {
        
    }
    
    public String getName () {
        return name;
    }
    
    public String getTanggallulus () {
        return tgl_lulus;
    }
    
    public String getFakultas () {
        return fakultas;
    }
}
