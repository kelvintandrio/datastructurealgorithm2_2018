import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Scanner;

abstract class Tree implements Comparable<Tree> {
    public final int frekuensi;
    public Tree (int freq) {
        frekuensi = freq;
    }
    public int compareTo (Tree tree) {
        return frekuensi - tree.frekuensi;
    }
}

class Leaf extends Tree {
    public final char value; 
    public Leaf(int freq, char val) {
        super(freq);
        value = val;
    }
}

class Node1 extends Tree {
    public final Tree left, right; // subtrees
    public Node1(Tree l, Tree r) {
        super(l.frekuensi + r.frekuensi);
        left = l;
        right = r;
    }
}

public class ProgramHuffman {
    static String[] huruf = new String[256];
    static String[] kode = new String[256];
    static int k = 0;
    
    public static void main (String[] args) {
        Scanner input = new Scanner (System.in);
        
        String data = "";
        
        System.out.print ("Input Data : ");
        String direktori = input.next();
        File file = new File(direktori);
        FileInputStream fis = null;
        BufferedInputStream bis = null;
        DataInputStream dis = null;

        try {
            fis = new FileInputStream(file);

            // di sini BufferedInputStream ditambahkan untuk pembacaan secara cepat.
            bis = new BufferedInputStream(fis);
            dis = new DataInputStream(bis);

            // dis.available() akan mengembalikan nilai 0 jika file sudah tidak punya baris lagi.
            while (dis.available() != 0) {
                data += dis.readLine();
                // statement ini membaca baris dari file dan menampilkannya ke console.
            }

            // buang semua resources setelah menggunakannya.
            fis.close();
            bis.close();
            dis.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        System.out.println("\nIsi Text : ");
        //data = input.nextLine();
        System.out.println(data);
        String data2 = data;
        
        int[] charFrekuensi = new int[256];
        for (char c : data2.toCharArray()) {
            charFrekuensi[c]++;
        }
        Tree tree = buildTree (charFrekuensi);
        System.out.println("SIMBOL\tBOBOT\tHUFFMAN CODE");
        code(tree, new StringBuffer());
        System.out.println("\n\nHuffman Encoding :\n");
        cetak(data2);
        System.out.println();
    }
    
    public static Tree buildTree(int[] charFreqs) {
        PriorityQueue<Tree> trees = new PriorityQueue<Tree>();
        for (int i = 0; i < charFreqs.length; i++) {
            if (charFreqs[i] > 0) {
                trees.offer(new Leaf(charFreqs[i], (char) i));  
            }
        }
        assert trees.size() > 0;
        while (trees.size() > 1) {
            Tree a = trees.poll();
            Tree b = trees.poll();
            trees.offer(new Node1(a, b)); 
        }
        return trees.poll();
    }
    
    public static void code(Tree tree, StringBuffer prefix) {
        String cetak = "";
        assert tree != null;
        if (tree instanceof Leaf) {
            Leaf leaf = (Leaf) tree;
            System.out.println(leaf.value+"\t"+leaf.frekuensi+"\t"+prefix);
            cetak = "";
            cetak += leaf.value;
            huruf[k] = cetak;
            kode[k] = prefix.toString();
            k++; } 
        else if (tree instanceof Node1) {
            Node1 node = (Node1) tree;
            prefix.append('0');
            code(node.left, prefix);
            prefix.deleteCharAt(prefix.length() - 1);
            prefix.append('1');
            code(node.right, prefix);
            prefix.deleteCharAt(prefix.length() - 1); }
    }

    public static void cetak(String h) {
        HashMap<String, String> compressed = new HashMap<>();
        String d = "";
        for (int i = 0; i < k; i++)
            compressed.put(huruf[i], kode[i]);
        for (int y = 0; y < h.length(); y++) {
            d += h.charAt(y);
            if (compressed.get(d) != null)
                System.out.print(compressed.get(d) + " ");
            d = ""; 
        }
    }
}
