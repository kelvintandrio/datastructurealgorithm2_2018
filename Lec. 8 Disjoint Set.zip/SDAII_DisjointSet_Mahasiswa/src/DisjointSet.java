
import java.util.Scanner;

public class DisjointSet {
    private static int[] DS = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int pilih = 0;

        do {

        }
        while(pilih != 3);
    }

    public static int Find (int X) {

    }

    // Union X -> Y
    public static void Union (int X, int Y) {

    }
}
