
import java.util.Scanner;


public class Home2 {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        HashTrie trie = new HashTrie();
        System.out.println("Welcome in Program TRIES :");
        int pilih = 0;
        do {
            System.out.println("Silahkan Pilih :\n1. Insert\n2. Print\n3. Search");
            System.out.print("Pilih : ");
            
        }
        while(pilih != 4);
    }
}
