
import java.util.HashMap;

public class HashTrie {
    private HashMap<Character, HashMap> root;
 
    /** Constructor **/
    public HashTrie() {
       root = new HashMap<>();
    }
 
    /** Function to add a string to hash trie **/
    public void add(String str) {
        
    }
 
    /** Function to check if hash trie contains a given word **/
    public boolean contains(String str) {
                 
    }
    
    public void printTries() {
        
    }
}